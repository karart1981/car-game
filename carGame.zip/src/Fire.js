import {ctx, canvas, grn} from './util.js'
export class Fire{

}

// https://cdn1.iconfinder.com/data/icons/food-4-9/128/Vigor_Fire-Hot-Flame-Burn-512.png