import { Game } from "./src/Game.js";
let app = new Game();
